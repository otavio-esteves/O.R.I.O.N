"""One-shot HOST evidence recorder for explicit temporary emulators; no app mutations."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--serial', required=True, choices=['emulator-5574'])
p.add_argument('--label', required=True)
p.add_argument('--expected', required=True, type=int)
p.add_argument('--classes')
p.add_argument('--qualification', action='store_true')
p.add_argument('--model', action='store_true')
a = p.parse_args()
assert re.fullmatch(r'[a-z0-9-]+', a.label)
root = Path(__file__).resolve().parents[2]
adb = ['/home/hellenc/Android/Sdk/platform-tools/adb', '-s', a.serial]
def call(*args):
    return subprocess.check_output(adb + list(args), text=True, timeout=30).strip()
def sha(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()
target = 'network.orion.qualification' if a.qualification else 'network.orion'
runner = ('network.orion.qualification.test/network.orion.app.compatibility.OrionQualificationInstrumentation'
          if a.qualification else 'network.orion.test/androidx.test.runner.AndroidJUnitRunner')
variant = 'qualificationRelease' if a.qualification else 'debug'
artifacts = [root / f'app/build/outputs/apk/{variant}/app-{variant}.apk',
             root / f'app/build/outputs/apk/androidTest/{variant}/app-{variant}-androidTest.apk']
out = root / 'build/integration-20261110' / a.label
out.mkdir(parents=True, exist_ok=True)
report = {'status': 'RUNNING', 'environment': 'ANDROID_EMULATOR', 'physicalQualification': False,
          'identityCapture': 'BEFORE_INSTRUMENTATION_WITH_INSTALLED_APK_HASH_CHECK',
          'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'serial': a.serial, 'expectedCases': a.expected, 'runner': runner,
          'recorderSha256': sha(__file__), 'sourceFreezeSha256': sha(root / 'build/integration-20261110/integrated-source.json'),
          'artifacts': {str(x.relative_to(root)): sha(x) for x in artifacts}}
log = out / 'instrumentation.log'
try:
    assert call('shell', 'getprop', 'ro.kernel.qemu') == '1'
    report['api'] = call('shell', 'getprop', 'ro.build.version.sdk')
    report['fingerprint'] = call('shell', 'getprop', 'ro.build.fingerprint')
    report['pageSize'] = call('shell', 'getconf', 'PAGE_SIZE')
    report['commit'] = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    report['installedSha256'] = {}
    window = call('shell','dumpsys','window')
    assert not any('mCurrentFocus=' in line and 'Application Not Responding' in line for line in window.splitlines()), 'Platform ANR; no tests started'
    for package, artifact in zip([target, target + '.test'], artifacts):
        path = call('shell', 'pm', 'path', package)
        assert path.startswith('package:') and '\n' not in path
        installed = call('shell', 'sha256sum', path.removeprefix('package:')).split()[0]
        assert installed == sha(artifact), 'Installed APK differs from recorded local artifact'
        report['installedSha256'][package] = installed
    command = adb + ['shell', 'am', 'instrument', '-w', '-r']
    if a.classes:
        command += ['-e', 'class', a.classes]
    if a.model:
        command += ['-e', 'orionModelPath', '/data/user/0/network.orion/files/qwen2.5-0.5b-instruct-q4_k_m.gguf',
                    '-e', 'orionEnvironment', 'ANDROID_EMULATOR']
    command += [runner]
    report['command'] = command
    (out / 'run.json').write_text(json.dumps(report, indent=2) + '\n')
    with log.open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=2400)
    content = log.read_text()
    report['logSha256'] = sha(log)
    report['assumptionSkips'] = len(re.findall(r'^INSTRUMENTATION_STATUS_CODE: -(?:3|4)$', content, re.M))
    report['failures'] = len(re.findall(r'^INSTRUMENTATION_STATUS_CODE: -(?:1|2)$', content, re.M))
    duration = re.search(r'^Time: ([0-9.]+)$', content, re.M)
    if duration:
        report['durationSeconds'] = float(duration[1])
    assert result.returncode == 0
    assert re.search(r'^OK \(' + str(a.expected) + r' tests?\)\s*$', content, re.M), 'Exact expected success count absent'
    assert report['assumptionSkips'] == 0 and report['failures'] == 0
    assert not any(x in content for x in ['FAILURES!!!', 'INSTRUMENTATION_FAILED', 'Process crashed', '\nFAIL:'])
    report['status'] = 'PASS'
except BaseException as e:
    report.update(status='FAIL', failureType=type(e).__name__, failure=str(e))
    raise
finally:
    (out / 'run.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
