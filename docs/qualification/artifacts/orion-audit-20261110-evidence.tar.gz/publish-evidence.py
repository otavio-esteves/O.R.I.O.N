from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess,datetime
r=Path(__file__).resolve().parent
repo=r.parents[1]
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
required=['api35-real-cortex','api37-full','api37-r8']
for run in required:assert read(r/run/'run.json')['status']=='PASS',run
for case in ['upgrade-api35/installed-upgrade-report.json','api37-model-file/transaction-process-death-report.json','api37-model-registered/transaction-process-death-report.json']:
 assert read(r/case)['result']=='PASS',case
ci=read(r/'component-ci.json');assert all(v['conclusion']=='success' for v in ci.values())
assert read(r/'cleanup.json')['ownedEmulatorsStopped']
# Every code/build/runtime input must match the candidate used in Docker and on Android.
frozen=read(r/'integrated-source.json')['files']
current=subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines()
non_docs=[p for p in current if not p.startswith('docs/')]
for p in non_docs:assert sha(repo/p)==frozen.get(p),p
proof={'validatedCandidate':read(r/'integrated-source.json')['commit'],'deliveryProductSourcesEqual':True,'comparedNonDocumentationFiles':len(non_docs)}
(r/'delivery-source-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
files=['api37-config.ini','api37-runtime-configuration.json','publish-evidence.py','component-tree-equality.json','github.json','component-ci.json','integration-state.json','integrated-source.json','artifact-source-lineage.json','delivery-source-verification.json','model-fixture.json','api35-boot.json','api35-config.ini','api37-boot.json','api37-setup-identity.json','api37-command.json','cleanup.json','run-instrumentation.py','component-merges.log']
for name in files:shutil.copy2(r/name,r/'evidence'/name)
for run in required+['upgrade-api35','api37-model-file','api37-model-registered']:
 shutil.copytree(r/run,r/'evidence'/run,dirs_exist_ok=True)
shutil.copy2(repo/'build/f5-upgrade-baseline/provenance.json',r/'evidence'/'upgrade-baseline-provenance.json')
shutil.copy2(repo/'build/f5-api37-16k-image/image-provenance.json',r/'evidence'/'api37-image-provenance.json')
manifest={str(p.relative_to(r/'evidence')):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted((r/'evidence').rglob('*')) if p.is_file()}
(r/'evidence'/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=repo/'docs/qualification/artifacts/orion-audit-20261110-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted((r/'evidence').rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(r/'evidence')),recursive=False)
report={'schemaVersion':1,'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'SOFTWARE_AUDIT_INTEGRATION_ONLY','source':proof,'sourceLineage':read(r/'artifact-source-lineage.json'),'reviews':read(r/'github.json'),'componentCI':ci,'validation':{run:read(r/run/'run.json') for run in required},'upgrade':read(r/'upgrade-api35/installed-upgrade-report.json'),'modelImportDeath':{case:read(r/case/'transaction-process-death-report.json') for case in ['api37-model-file','api37-model-registered']},'historicalValidation':{'canonical':'PASS','jvmCases':798,'jvmSuites':108,'hostHarnessCases':127,'focusedJvmCases':176,'api35BinderOwnerModelCases':26,'api35ClientQueueCases':15,'api35R8Cases':3,'precedingPersistenceCases':75,'scope':'Original logged working-tree candidates; exact manifests and APK hashes retained in bundle. Counts overlap and must not be summed.'},'evidenceBundle':{'path':str(archive.relative_to(repo)),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':manifest},'deliveryRequiredCheck':'docker-build-and-check; exact delivery-head result recorded in the protected-main PR before merge','physicalQualification':False,'f5Status':'OPEN','cortexRuntimeReady':False,'productionInferenceEnabled':False,'pending':['Physical Galaxy S21 arm64/model/resource/thermal/battery qualification','Physical API37 MemoryLimiter and policy calibration','Complete native/API physical load matrix and approved production profiles','At least 24 real elapsed hours of post-Cortex soak plus memory stress','Remaining F4 stability prerequisite #64','F6 implementation after the preceding gates pass'],'physicalTrackingIssue':'https://github.com/otavio-esteves/O.R.I.O.N/issues/89','cleanup':read(r/'cleanup.json')}
(repo/'docs/qualification/audit-20261110-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(r/'integration-work-package.md',repo/'docs/issues/ORION-AUDIT-INTEGRATION-001.md')
shutil.copy2(r/'f5-physical-issue.md',repo/'docs/issues/ORION-F5-QUAL-001.md')
print('Evidence bundle prepared',archive.stat().st_size,'bytes',len(manifest),'files')
