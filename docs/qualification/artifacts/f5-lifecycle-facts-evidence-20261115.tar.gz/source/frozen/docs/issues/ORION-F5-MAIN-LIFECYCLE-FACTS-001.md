# ORION-F5-MAIN-LIFECYCLE-FACTS-001 — passive original lifecycle facts

Tracking: https://github.com/otavio-esteves/O.R.I.O.N/issues/132.
Base: 0ac873a. No original lifecycle regression test is replaced.

OBJECTIVE: Retain optional bounded MAIN lifecycle metadata from existing original
deadline samples and content-byte validation results, and associate the call-local
collector only with the actual runOnce owner. This is partial software evidence,
not exact callback/native timing or a RuntimeEvidence v1 producer.

FILES ALLOWED: ai/api lifecycle, new final buffer/types and focused JVM tests;
Client scoped composition; cycle observer/receipt bounded association/manual
snapshot; focused Android tests; this work package and qualification note. No
Foundation/flag/bridge/runner, formatter125/HOST130, wire/AIDL/protocol/service/
native, resource policy, persistence, profile or configuration changes.

CONTRACTS INVOLVED: Original synchronized lifecycle validation/reorder/dedup/
terminality, original Client/Owner/ledger/turnstile, existing byte validation and
OrionClock. Accepted ADR0001/0002/0003 unaffected; no IPC semantics change.

INVARIANTS INVOLVED: INV-009/011/012/013/019/027/028/032/035/036.

TESTS REQUIRED: Same original clock count/order/status/output/Throwable/List;
schema/no-clock, deadline/invalid boot/regression/terminal idempotency and origin;
buffered admission versus ordered release and delivery; reused validated total
UTF8 bytes (not separate text/tool counts); ignored/duplicate/conflict/wrong input;
reserved terminal under saturation/contention, bounded immutable loss/faults;
actual-owner/replay/queue/cancel/error association with no added RPC/Clock. Tests
are supplied only: root executes all Kotlin/HOST/Gradle/Docker/ADB/CI checks.

ACCEPTANCE CRITERIA: Optional final collector default null; no diagnostic object
or enum initialization outside guards when disabled. Existing Clock read and
deadline classification stay outside diagnostic catches and occur once unchanged.
Samples are operation-local associated ORIGINAL DEADLINE SAMPLES, never exact
callback/export/native event timestamps or a previous operation's sample. First
terminal uses a reserved slot only after successful original finish. Chunk records
publish only after constructing the original update, without content/IDs/hashes,
reencoding or validation calls. Bounded scalar bookkeeping inside accept is allowed;
buffer snapshot/copy occurs only in the separate manual receipt phase, never on
Client return/cleanup. Replay constructor facts never attach to retained inference.
Metadata failures/loss remain unavailable;125 stays byte-for-byte unchanged.

OUT OF SCOPE: RuntimeEvidence v1 completion, load/unload or multi-phase memory
sampler, timing reconstruction, any formatter/driver/HOST changes, templates/
models/calibration/profiles, physical/native performance/soak/F5/F6 closure.

VALIDATION: Implementation and source tests pending. No tests, compiler, Gradle,
Docker, ADB or device execution by this author; root centralizes validation.
