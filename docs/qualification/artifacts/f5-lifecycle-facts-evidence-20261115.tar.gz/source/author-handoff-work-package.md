# ORION-F5-MAIN-LIFECYCLE-FACTS-001 — passive original lifecycle facts

Tracking: https://github.com/otavio-esteves/O.R.I.O.N/issues/132.
Base: 0ac873a. No original lifecycle regression test is replaced.

OBJECTIVE: Retain optional bounded MAIN lifecycle metadata from existing original
deadline samples and content-byte validation results, and associate the call-local
collector only with the actual runOnce owner. This is partial software evidence,
not exact callback/native timing or a RuntimeEvidence v1 producer.

FILES ALLOWED: ai/api lifecycle, new final buffer/types and focused JVM tests;
Client scoped composition; cycle observer/receipt bounded association/manual
snapshot; focused Android tests; this work package and qualification note. No
Foundation/flag/bridge/runner, formatter125/HOST130, wire/AIDL/protocol/service/
native, resource policy, persistence, profile or configuration changes.

CONTRACTS INVOLVED: Original synchronized lifecycle validation/reorder/dedup/
terminality, original Client/Owner/ledger/turnstile, existing byte validation and
OrionClock. Accepted ADR0001/0002/0003 unaffected; no IPC semantics change.

INVARIANTS INVOLVED: INV-009/011/012/013/019/027/028/032/035/036.

TESTS REQUIRED: Same original clock count/order/status/output/Throwable/List;
schema/no-clock, deadline/invalid boot/regression/terminal idempotency and origin;
buffered admission versus ordered release and delivery; reused validated total
UTF8 bytes (not separate text/tool counts); ignored/duplicate/conflict/wrong input;
reserved terminal under saturation/contention, bounded immutable loss/faults;
actual-owner/replay/queue/cancel/error association with no added RPC/Clock. Tests
are supplied only: root executes all Kotlin/HOST/Gradle/Docker/ADB/CI checks.

ACCEPTANCE CRITERIA: Optional final collector default null; no diagnostic object
or enum initialization outside guards when disabled. Existing Clock read and
deadline classification stay outside diagnostic catches and occur once unchanged.
Samples are operation-local associated ORIGINAL DEADLINE SAMPLES, never exact
callback/export/native event timestamps or a previous operation's sample. First
terminal uses a reserved slot only after successful original finish. Chunk records
publish only after constructing the original update, without content/IDs/hashes,
reencoding or validation calls. Bounded scalar bookkeeping inside accept is allowed;
buffer snapshot/copy occurs only in the separate manual receipt phase, never on
Client return/cleanup. Replay constructor facts never attach to retained inference.
Metadata failures/loss remain unavailable;125 stays byte-for-byte unchanged.

OUT OF SCOPE: RuntimeEvidence v1 completion, load/unload or multi-phase memory
sampler, timing reconstruction, any formatter/driver/HOST changes, templates/
models/calibration/profiles, physical/native performance/soak/F5/F6 closure.

IMPLEMENTATION: The final opt-in buffer retains bounded deadline samples and
constructed-update metadata, plus an independent first-terminal slot. The Client
attaches its call-local source only inside the actual runOnce operation; manual
cycle receipts may snapshot it. Buffered admission, ordered release and downstream
callback attempts/returns remain distinct. No format125/HOST130, IPC, resource,
profile, persistence or process-boundary changes are included.

VALIDATION (partial, 2026-11-15): Root reported Docker execution on the integrated
copy at `/tmp/orion-lifecycle-facts-delivery-20261115`: 48 ai/api JVM tests passed
(including the 15 new lifecycle-fact regressions), and 216 app JVM tests passed.
Kotlin AndroidTest compilation passed; native packaging remains in progress.
No app Android runtime test has been executed for this package, and a complete
integrated build, Android execution and CI remain pending. The source author ran
`git diff --check` only; no compiler, Gradle, Docker or ADB execution by this author.
An independent read-only review found no blocking code issue. The original
lifecycle regression file and formatter125 remain unchanged.

RECOVERY / PRIVACY / UPGRADE: These are bounded ephemeral MAIN observations only.
Process death discards them without inference replay or restart-policy changes.
They retain no prompt/text/tool content, request/model identifiers, content hashes
or raw errors. There is no schema, migration, backup or durable-state change.
This is partial software preparation, not complete RuntimeEvidence v1, native
performance, physical/API qualification, F5/F6 closure or operational admission.
