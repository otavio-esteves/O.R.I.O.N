from pathlib import Path
import datetime,hashlib,json,re,subprocess,time
base=Path('/tmp/orion-runner-investigation-20261115')
report_path=base/'plan-and-results.json'
report=json.loads(report_path.read_text())
adb=['/home/otavio/Android/Sdk/platform-tools/adb','-s','emulator-5584']
package='network.orion.qualification'
component=package+'.test/network.orion.app.compatibility.OrionCortexSingleAttemptInstrumentation'
def command(*args,timeout=180,required=True):
    result=subprocess.run(adb+list(args),text=True,capture_output=True,timeout=timeout)
    if required: result.check_returncode()
    return result

def save(): report_path.write_text(json.dumps(report,indent=2)+'\n')
start=time.monotonic()
while time.monotonic()-start<240:
    state=command('shell','getprop','sys.boot_completed',timeout=5,required=False)
    if state.returncode==0 and state.stdout.strip()=='1':break
    time.sleep(2)
else:
    report['bootstrapFailure']='EMULATOR_BOOT_TIMEOUT';save();raise RuntimeError('Own emulator boot unavailable')
command('shell','input','keyevent','82')
report['device']={
    'api':command('shell','getprop','ro.build.version.sdk').stdout.strip(),
    'abi':command('shell','getprop','ro.product.cpu.abi').stdout.strip(),
    'pageSize':command('shell','getconf','PAGE_SIZE').stdout.strip(),
    'build':command('shell','getprop','ro.build.fingerprint').stdout.strip()}
report['installedHashes']={}
for name,pkg in [('app-qualificationRelease.apk',package),('app-qualificationRelease-androidTest.apk',package+'.test')]:
    artifact=Path('/tmp/orion-fixes-qualification')/name
    assert hashlib.sha256(artifact.read_bytes()).hexdigest()==report['artifacts'][name]
    command('install','-r',str(artifact))
    remote=command('shell','pm','path',pkg).stdout.strip().removeprefix('package:')
    assert remote.startswith('/data/app/') and '\n' not in remote
    pulled=base/(pkg+'-installed.apk')
    command('pull',remote,str(pulled))
    digest=hashlib.sha256(pulled.read_bytes()).hexdigest()
    assert digest==report['artifacts'][name]
    report['installedHashes'][pkg]=digest
save()
for number,case in enumerate(report['plannedCases'],1):
    if number==2:
        command('shell','am','force-stop',package)
    if number==3:
        # Only the disposable qualification identity in this own fresh AVD is reset.
        cleared=command('shell','pm','clear',package).stdout.strip()
        assert cleared=='Success',cleared
    run_dir=base/f'run-{number:02d}-{case}'
    run_dir.mkdir(exist_ok=True)
    before={name:command('shell','pidof',name,required=False).stdout.strip()
            for name in [package,package+':ai']}
    command('logcat','-c')
    entry={'number':number,'case':case,'beforePids':before,
           'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    began=time.monotonic()
    try:
        result=command('shell','am','instrument','-w','-r',component,timeout=120,required=False)
        text=result.stdout
        (run_dir/'instrumentation-raw.log').write_text(text)
        (run_dir/'instrumentation-stderr.log').write_text(result.stderr)
        entry['hostExitCode']=result.returncode
        header=next((line.split('=',1)[1] for line in text.splitlines()
                     if line.startswith('INSTRUMENTATION_RESULT: orionSingleAttemptStatus=')),None)
        entry['rawHeaderCaptured']=header is not None
        entry['status']=json.loads(header) if header is not None else None
        entry['instrumentationCode']=next((line.split(':',1)[1].strip() for line in text.splitlines()
                                          if line.startswith('INSTRUMENTATION_CODE:')),None)
        status=entry['status'] or {}
        entry['expectedNegativeObservation']=(entry['instrumentationCode']=='-1'
            and status.get('phase')=='PREPARE_REFUSED' and status.get('refusal')=='NO_QUALIFIED_PROFILE'
            and status.get('prepareCalls')==1
            and all(status.get(key)==0 for key in ['executeCalls','readCalls','releaseCalls'])
            and status.get('qualification')=='NOT_QUALIFIED'
            and all(status.get(flag) is False for flag in ['sourceAuthenticated','physicalVerified','profileApproved',
                'productionInferenceApproved','runtimeEvidenceV1Complete','fullF5GateClosed','fullSoakGateClosed','f6Authorized']))
    except subprocess.TimeoutExpired as failure:
        raw=failure.stdout or b''
        (run_dir/'instrumentation-raw.log').write_bytes(raw.encode() if isinstance(raw,str) else raw)
        entry['hostTimedOut']=True;entry['expectedNegativeObservation']=False
    finally:
        entry['hostElapsedSeconds']=round(time.monotonic()-began,3)
        entry['afterPids']={name:command('shell','pidof',name,required=False).stdout.strip()
                           for name in [package,package+':ai']}
        technical=command('logcat','-d','-v','threadtime','-s','orion_core:I','orion_maintenance:I','AndroidRuntime:E','*:S',required=False).stdout
        (run_dir/'technical-logcat-immediate.log').write_text(technical)
        time.sleep(2)
        technical=command('logcat','-d','-v','threadtime','-s','orion_core:I','orion_maintenance:I','AndroidRuntime:E','*:S',required=False).stdout
        (run_dir/'technical-logcat-after-2s.log').write_text(technical)
        report['runs'].append(entry);save()
    print(json.dumps({'number':number,'case':case,'expectedNegativeObservation':entry['expectedNegativeObservation'],
                      'status':entry.get('status'),'hostElapsedSeconds':entry['hostElapsedSeconds']}),flush=True)
report['completedInstrumentationAttempts']=len(report['runs'])
report['allExpectedNegativeObservations']=all(run['expectedNegativeObservation'] for run in report['runs'])
report['originalAttempt']['retrospectiveCause']='INDETERMINATE_NO_RAW_HEADER'
save()
