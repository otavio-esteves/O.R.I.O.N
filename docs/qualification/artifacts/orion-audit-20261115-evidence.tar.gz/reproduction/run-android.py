from pathlib import Path
import hashlib, json, re, shutil, subprocess
root = Path('/home/otavio/Projects/O.R.I.O.N')
output = Path('/tmp/orion-fixes-android')
output.mkdir(exist_ok=True)
adb = ['/home/otavio/Android/Sdk/platform-tools/adb', '-s', 'emulator-5590']
source = json.loads(Path('/tmp/orion-fixes-source-sha256.json').read_text())
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in source.items())
def run(*args, timeout=180):
    result = subprocess.run(adb + list(args), capture_output=True, text=True, timeout=timeout)
    result.check_returncode()
    return result.stdout
report = {'environment': 'ANDROID_EMULATOR', 'physicalQualification': False, 'source': source,
          'api': run('shell', 'getprop', 'ro.build.version.sdk').strip(),
          'pageSize': run('shell', 'getconf', 'PAGE_SIZE').strip(), 'artifacts': {}, 'checks': {}}
for package, relative in [('network.orion', 'app/build/outputs/apk/debug/app-debug.apk'),
                          ('network.orion.test', 'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk')]:
    target = output / Path(relative).name
    shutil.copy2(root / relative, target)
    expected = hashlib.sha256(target.read_bytes()).hexdigest()
    run('install', '-r', str(target))
    remote = run('shell', 'pm', 'path', package).strip().removeprefix('package:')
    assert remote.startswith('/data/app/') and '\n' not in remote
    installed = output / (package + '-installed.apk')
    run('pull', remote, str(installed))
    assert hashlib.sha256(installed.read_bytes()).hexdigest() == expected
    report['artifacts'][package] = expected
for label, selection in [('retention_regression', 'network.orion.app.reminders.OrionReminderKernelTest#historicalStatusReplaySurvivesPublishedEventRetentionAndReopen'),
                         ('related_persistence', ','.join(['network.orion.app.reminders.OrionReminderKernelTest',
                                                          'network.orion.app.OrionRetentionMaintenanceTest',
                                                          'network.orion.app.TransactionCorePersistenceTest']))]:
    text = run('shell', 'am', 'instrument', '-w', '-e', 'class', selection,
               'network.orion.test/androidx.test.runner.AndroidJUnitRunner', timeout=300)
    (output / (label + '.log')).write_text(text)
    match = re.search(r'OK \((\d+) tests?\)', text)
    assert match and 'FAILURES!!!' not in text, text
    report['checks'][label] = {'result': 'PASS', 'tests': int(match.group(1))}
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(label, report['checks'][label], flush=True)
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in source.items())
