from pathlib import Path
import hashlib, json, shutil, subprocess
root = Path('/home/otavio/Projects/O.R.I.O.N')
output = Path('/tmp/orion-fixes-qualification')
output.mkdir(exist_ok=True)
adb = ['/home/otavio/Android/Sdk/platform-tools/adb', '-s', 'emulator-5590']
source = json.loads(Path('/tmp/orion-fixes-source-sha256.json').read_text())
assert all(hashlib.sha256((root / p).read_bytes()).hexdigest() == h for p, h in source.items())
def run(*args, timeout=180):
    result = subprocess.run(adb + list(args), capture_output=True, text=True, timeout=timeout)
    result.check_returncode()
    return result.stdout
report = {'environment': 'ANDROID_EMULATOR', 'physicalQualification': False, 'source': source, 'artifacts': {}}
for package, folder in [('network.orion.qualification', 'app/build/outputs/apk/qualificationRelease'),
                        ('network.orion.qualification.test', 'app/build/outputs/apk/androidTest/qualificationRelease')]:
    metadata = json.loads((root / folder / 'output-metadata.json').read_text())
    assert metadata['applicationId'] == package and len(metadata['elements']) == 1
    artifact = root / folder / metadata['elements'][0]['outputFile']
    target = output / artifact.name
    shutil.copy2(artifact, target)
    expected = hashlib.sha256(target.read_bytes()).hexdigest()
    run('install', '-r', str(target))
    remote = run('shell', 'pm', 'path', package).strip().removeprefix('package:')
    assert remote.startswith('/data/app/') and '\n' not in remote
    installed = output / (package + '-installed.apk')
    run('pull', remote, str(installed))
    assert hashlib.sha256(installed.read_bytes()).hexdigest() == expected
    report['artifacts'][package] = expected
text = run('shell', 'am', 'instrument', '-w', '-r', 'network.orion.qualification.test/network.orion.app.compatibility.OrionCortexSingleAttemptInstrumentation')
(output / 'single_attempt.log').write_text(text)
header = next(line.split('=', 1)[1] for line in text.splitlines()
              if line.startswith('INSTRUMENTATION_RESULT: orionSingleAttemptStatus='))
status = json.loads(header)
assert 'INSTRUMENTATION_CODE: -1' in text, text
assert status['phase'] == 'PREPARE_REFUSED' and status['refusal'] == 'NO_QUALIFIED_PROFILE', status
assert status['prepareCalls'] == 1 and status['executeCalls'] == status['readCalls'] == status['releaseCalls'] == 0
assert status['qualification'] == 'NOT_QUALIFIED' and status['ownerCallInvoked'] is None
for flag in ['sourceAuthenticated','physicalVerified','profileApproved','productionInferenceApproved',
             'runtimeEvidenceV1Complete','fullF5GateClosed','fullSoakGateClosed','f6Authorized']:
    assert status[flag] is False
report['result'] = 'PASS'
report['status'] = status
(output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print('Qualification single-attempt R8: PASS; NO_QUALIFIED_PROFILE; no execution or inference.', flush=True)
