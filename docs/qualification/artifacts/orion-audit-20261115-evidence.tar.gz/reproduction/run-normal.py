from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess,time
root=Path('/home/otavio/Projects/O.R.I.O.N')
base=Path('/tmp/orion-normal-variant-scope-20261115')
report_path=base/'results.json'
report=json.loads(report_path.read_text())
assert (base/'root-build-complete.json').is_file(),'Wait for explicit root build completion notice before running'
report['rootBuildNotice']=json.loads((base/'root-build-complete.json').read_text())
adb=['/home/otavio/Android/Sdk/platform-tools/adb','-s','emulator-5584']
def command(*args,timeout=180,required=True):
 result=subprocess.run(adb+list(args),capture_output=True,text=True,timeout=timeout)
 if required: result.check_returncode()
 return result

def save():report_path.write_text(json.dumps(report,indent=2)+'\n')
start=time.monotonic()
while time.monotonic()-start<240:
 result=command('shell','getprop','sys.boot_completed',timeout=5,required=False)
 if result.returncode==0 and result.stdout.strip()=='1':break
 time.sleep(2)
else:raise RuntimeError('Own emulator did not boot within recorded bound')
command('shell','input','keyevent','82')
report['device']={'api':command('shell','getprop','ro.build.version.sdk').stdout.strip(),
                 'abi':command('shell','getprop','ro.product.cpu.abi').stdout.strip(),
                 'pageSize':command('shell','getconf','PAGE_SIZE').stdout.strip(),
                 'build':command('shell','getprop','ro.build.fingerprint').stdout.strip()}
target=root/'app/build/outputs/apk/debug/app-debug.apk'
frozen=base/'app-debug-normal-both-flags.apk'
shutil.copy2(target,frozen)
report['targetApk']={'file':frozen.name,'sha256':hashlib.sha256(frozen.read_bytes()).hexdigest()}
report['sourceAtTargetFreeze']={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
                              'changedFiles':{}}
paths=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
paths+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
for path in paths:
 report['sourceAtTargetFreeze']['changedFiles'][path]=hashlib.sha256((root/path).read_bytes()).hexdigest()
report['installedHashes']={}
for package,artifact,expected in [('network.orion',frozen,report['targetApk']['sha256']),
                                 ('network.orion.test',base/report['testApk']['file'],report['testApk']['sha256'])]:
 assert hashlib.sha256(artifact.read_bytes()).hexdigest()==expected
 command('install','-r',str(artifact))
 remote=command('shell','pm','path',package).stdout.strip().removeprefix('package:')
 assert remote.startswith('/data/app/') and '\n' not in remote
 installed=base/(package+'-installed.apk')
 command('pull',remote,str(installed))
 digest=hashlib.sha256(installed.read_bytes()).hexdigest()
 assert digest==expected
 report['installedHashes'][package]=digest
save()
for number,method in enumerate(report['selectedMethods'],1):
 directory=base/f'run-{number:02d}'
 directory.mkdir(exist_ok=True)
 selected='network.orion.app.'+method
 entry={'number':number,'selection':selected,'startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 command('logcat','-c')
 start=time.monotonic()
 result=command('shell','am','instrument','-w','-r','-e','class',selected,
                'network.orion.test/androidx.test.runner.AndroidJUnitRunner',timeout=120,required=False)
 entry['elapsedHostSeconds']=round(time.monotonic()-start,3)
 (directory/'instrumentation-raw.log').write_text(result.stdout)
 (directory/'instrumentation-stderr.log').write_text(result.stderr)
 entry['hostExitCode']=result.returncode
 match=re.search(r'OK \((\d+) tests?\)',result.stdout)
 entry['tests']=int(match.group(1)) if match else None
 entry['passed']=(entry['tests']==1 and 'INSTRUMENTATION_CODE: -1' in result.stdout
                  and 'FAILURES!!!' not in result.stdout
                  and not re.search(r'INSTRUMENTATION_STATUS_CODE: -(?:1|2|3|4)',result.stdout))
 entry['aiPidAfter']=command('shell','pidof','network.orion:ai',required=False).stdout.strip()
 technical=command('logcat','-d','-v','threadtime','-s','orion_core:I','AndroidRuntime:E','*:S',required=False).stdout
 (directory/'technical-logcat.log').write_text(technical)
 report['runs'].append(entry);save()
 print(json.dumps(entry),flush=True)
 if not entry['passed']:raise RuntimeError('Selected normal-variant assertion failed; original result preserved')
report['result']='PASS'
report['inferenceCommandIssued']=False
report['qualificationOrF6GateClosed']=False
save()
