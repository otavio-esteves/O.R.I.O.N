package network.orion.app.ai

import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import network.orion.ai.api.OrionInferenceLifecycle
import network.orion.ai.api.OrionInferenceChunk
import network.orion.ai.api.OrionInferenceRequest
import network.orion.ai.api.OrionInferenceStatus
import network.orion.app.resources.OrionAndroidResourceObserver
import network.orion.app.resources.OrionCortexMemoryTelemetry
import network.orion.app.resources.OrionCortexResourceFactBuffer
import network.orion.app.resources.recordGovernorFact
import network.orion.app.resources.recordRestartFact
import network.orion.core.resources.OrionCortexRestartGuard
import network.orion.core.resources.OrionInferenceResourcePlan
import network.orion.core.resources.OrionMinimumResourceGovernor
import network.orion.core.resources.OrionResourceObservation
import network.orion.core.time.OrionClock
import network.orion.data.database.ModelRegistryEntity
import network.orion.data.database.OrionDatabase
import network.orion.data.repository.models.OrionModelImportCoordinator

internal data class OrionCortexResourceTiming(val maximumObservationAgeMillis: Long, val memoryExitCooldownMillis: Long) {
    init { require(maximumObservationAgeMillis > 0 && memoryExitCooldownMillis > 0) }
}

internal enum class OrionCortexUnavailable {
    CLOSED, NO_QUALIFIED_PROFILE, RESOURCE_CONFIGURATION_UNAVAILABLE, CORE_NOT_READY,
    PROCESS_INVENTORY_UNAVAILABLE, MODEL_NOT_READY, MODEL_UNAVAILABLE, PROFILE_MISMATCH, REQUEST_RETIRED,
}

/** Read-only early configuration state. No entry represents a resource or restart permit. */
internal enum class OrionCortexPreResourceReadiness(val unavailable: OrionCortexUnavailable?) {
    CLOSED(OrionCortexUnavailable.CLOSED),
    NO_QUALIFIED_PROFILE(OrionCortexUnavailable.NO_QUALIFIED_PROFILE),
    RESOURCE_CONFIGURATION_UNAVAILABLE(OrionCortexUnavailable.RESOURCE_CONFIGURATION_UNAVAILABLE),
    CORE_NOT_READY(OrionCortexUnavailable.CORE_NOT_READY),
    DECISION_NOT_EVALUATED(null),
}

/** Exact shared early predicates; later sources stay lazy after an earlier refusal. */
internal inline fun evaluateCortexPreResourceReadiness(isClosed: () -> Boolean,
    hasQualifiedPlans: () -> Boolean, hasTiming: () -> Boolean, isCoreReady: () -> Boolean): OrionCortexPreResourceReadiness = when {
    isClosed() -> OrionCortexPreResourceReadiness.CLOSED
    !hasQualifiedPlans() -> OrionCortexPreResourceReadiness.NO_QUALIFIED_PROFILE
    !hasTiming() -> OrionCortexPreResourceReadiness.RESOURCE_CONFIGURATION_UNAVAILABLE
    !isCoreReady() -> OrionCortexPreResourceReadiness.CORE_NOT_READY
    else -> OrionCortexPreResourceReadiness.DECISION_NOT_EVALUATED
}

internal sealed interface OrionCortexRunResult {
    data class Unavailable(val reason: OrionCortexUnavailable) : OrionCortexRunResult
    data class Completed(val status: OrionInferenceStatus) : OrionCortexRunResult
}

/** MAIN technical owner. Empty trusted configuration cannot bind, probe storage or grant inference. */
internal class OrionCortexRuntimeOwner(
    context: Context,
    private val importer: OrionModelImportCoordinator,
    private val database: OrionDatabase,
    private val clock: OrionClock,
    qualifiedPlans: List<OrionInferenceResourcePlan> = emptyList(),
    private val timing: OrionCortexResourceTiming? = null,
    private val coreReady: () -> Boolean = { false },
    private val resourceFacts: OrionCortexResourceFactBuffer? = null,
    private val cycleObservations: OrionCortexCycleObserver? = null,
    private val singleAttemptTemplate: OrionCortexAttemptTemplate? = null,
) : AutoCloseable {
    private val app = context.applicationContext
    private val plans = qualifiedPlans.toList()
    private val byId = plans.associateBy { it.model.modelId }
    private val monitor = Any()
    private val resourceMonitor = Any()
    private val recovery = Mutex()
    @Volatile private var closed = false
    @Volatile private var client: OrionCortexClient? = null
    private var observation: OrionResourceObservation? = null
    private var recoveryAfter: String? = null
    private var recoveryComplete = false
    private var copiesClean = false
    private var unregisteredAfter: String? = null
    private var unregisteredClean = false
    private val requestHistory = OrionInferenceRequestLedger()
    private val cycleScope = cycleObservations.isolatedCycle { Any() }
    fun newRequestId(): String { check(!closed); return requestHistory.newRequestId() }
    private val governor = timing?.takeIf { plans.isNotEmpty() }?.let {
        OrionMinimumResourceGovernor(clock, { observation }, plans, it.maximumObservationAgeMillis, it.memoryExitCooldownMillis)
    }
    private val restart = timing?.takeIf { plans.isNotEmpty() }?.let {
        OrionCortexRestartGuard(clock, plans, it.maximumObservationAgeMillis, it.memoryExitCooldownMillis)
    }
    private val telemetry = timing?.let { OrionCortexMemoryTelemetry(app.packageName, clock, it.maximumObservationAgeMillis) }
    private val observer = timing?.let { limits -> OrionAndroidResourceObserver(app, clock,
        auxiliaryMemory = {
            val inventory = discoverInventory() ?: return@OrionAndroidResourceObserver null
            val selectedClient = client ?: return@OrionAndroidResourceObserver null
            val captureWindow = selectedClient.runtimeHealthWindow()
            val receipt = selectedClient.currentMemoryTelemetry() ?: return@OrionAndroidResourceObserver null
            // Reuse exactly the original parse/validation/Clock read; capture consumes only its typed result.
            telemetry?.let { adapter ->
                val originalPid = receipt.getInt("pid")
                val evidence = adapter.read(receipt, originalPid, inventory, true)
                selectedClient.runtimeMemoryValidated(captureWindow, originalPid, evidence?.sampledAt)
                evidence
            }
        }, maximumMemoryAgeMillis = limits.maximumObservationAgeMillis) }

    init {
        require(Application.getProcessName() == app.packageName) { "Cortex runtime belongs to MAIN." }
        require(plans.size <= 64 && byId.size == plans.size && plans.all { validModelHash(it.model.modelId) })
    }

    /** Stops before inventory, storage, Binder, governor or restart evaluation, even when configured. */
    internal fun preResourceReadiness(): OrionCortexPreResourceReadiness = evaluateCortexPreResourceReadiness(
        { closed }, { plans.isNotEmpty() }, { timing != null }, coreReady)

    /** Candidature only. Early refusals precede even the one selected registry lookup. */
    internal suspend fun selectSingleAttemptTemplate(): OrionCortexAttemptConfiguration = withContext(Dispatchers.IO) {
        fun refuse(reason: OrionCortexAttemptRefusal) = OrionCortexAttemptConfiguration.Refused(reason)
        preResourceReadiness().unavailable?.let { return@withContext refuse(singleAttemptRefusal(it)) }
        if (cycleScope == null) return@withContext refuse(OrionCortexAttemptRefusal.OBSERVER_UNAVAILABLE)
        val template = singleAttemptTemplate ?: return@withContext refuse(OrionCortexAttemptRefusal.TEMPLATE_UNAVAILABLE)
        if (!template.isValid()) return@withContext refuse(OrionCortexAttemptRefusal.TEMPLATE_INVALID)
        val plan = byId[template.modelId] ?: return@withContext refuse(OrionCortexAttemptRefusal.PROFILE_MISMATCH)
        val selected = database.models().find(template.modelId)
        if (selected?.status != "READY") return@withContext refuse(OrionCortexAttemptRefusal.MODEL_NOT_READY)
        if (!profileMatchesReadyModel(plan, selected, template.contextTokens, template.threads, template.maxTokens))
            return@withContext refuse(OrionCortexAttemptRefusal.PROFILE_MISMATCH)
        OrionCortexAttemptConfiguration.Ready(template)
    }

    /** Called only after candidate consumption and observer reservation, never for evidence time. */
    internal fun prepareSingleAttemptRequest(template: OrionCortexAttemptTemplate): OrionInferenceRequest? {
        if (closed || template !== singleAttemptTemplate) return null
        val now = clock.monotonicNow()
        if (now.bootSessionId == null) return null
        val deadline = now.deadlineAfter(template.requestDurationMillis)
        val id = newRequestId()
        return OrionInferenceRequest(id, 1, template.modelId, template.workloadPrompt, template.workloadContext,
            template.maxTokens, template.temperature, template.priority, deadline, id)
    }

    internal fun discardSingleAttemptReservation(token: OrionCortexCycleToken): Boolean = cycleScope?.let { scope ->
        cycleObservations.isolatedCycle(token) { it.discardUnclaimed(scope, token) }
    } == true

    fun beginCycleObservation(): OrionCortexCycleToken? = cycleScope?.let { scope ->
        cycleObservations.isolatedCycle { it.begin(scope) }
    }

    /** The token is technical observation ownership, never request/profile/admission authority. */
    suspend fun runObserved(token: OrionCortexCycleToken?, modelId: String, request: OrionInferenceRequest,
        contextTokens: Int, threads: Int, onChunks: (List<OrionInferenceChunk>) -> Unit): OrionCortexRunResult {
        val capture = cycleScope?.let { scope -> cycleObservations.isolatedCycle(token) { it.claim(scope, token) } }
        return try {
            val result = runOwned(modelId, request, contextTokens, threads, onChunks, capture)
            cycleObservations.isolatedCycle(capture) { it.returned(capture, result) }
            result
        } catch (failure: Throwable) {
            cycleObservations.isolatedCycle(capture) { it.threw(capture, when (failure) {
                is CancellationException -> OrionCycleThrown.CANCELLED
                is InterruptedException -> OrionCycleThrown.INTERRUPTED
                else -> OrionCycleThrown.OTHER
            }) }
            throw failure
        }
    }

    /** Explicit internal preparation only; no factory activation, workload choice or admission. */
    internal fun beginRuntimeCapture(): OrionCortexRuntimeCaptureSession? = try {
        if (closed) null else OrionCortexRuntimeCaptureSession.create(this, android.os.Process.myPid())
    } catch (_: Throwable) { null }

    /** Same original path and original callback; normal run/runObserved remain capture-absent. */
    internal suspend fun runCaptured(capture: OrionCortexRuntimeCaptureSession?, modelId: String, request: OrionInferenceRequest,
        contextTokens: Int, threads: Int, onChunks: (List<OrionInferenceChunk>) -> Unit): OrionCortexRunResult {
        val selected = capture?.takeIf { it.claim(this) }
        return try {
            val original = runOwned(modelId, request, contextTokens, threads, onChunks, null, selected)
            selected?.runReturned(false)
            original
        } catch (failure: Throwable) { selected?.runReturned(true); throw failure }
    }

    internal fun readRuntimeCapture(capture: OrionCortexRuntimeCaptureSession): OrionRuntimeSessionReceipt? = capture.readAfterRun(this)

    suspend fun run(modelId: String, request: OrionInferenceRequest, contextTokens: Int, threads: Int,
        onChunks: (List<OrionInferenceChunk>) -> Unit): OrionCortexRunResult =
        runOwned(modelId, request, contextTokens, threads, onChunks, null)

    private suspend fun runOwned(modelId: String, request: OrionInferenceRequest, contextTokens: Int, threads: Int,
        onChunks: (List<OrionInferenceChunk>) -> Unit, cycle: OrionCortexCycleToken?,
        runtimeCapture: OrionCortexRuntimeCaptureSession? = null): OrionCortexRunResult = withContext(Dispatchers.IO) {
        fun unavailable(reason: OrionCortexUnavailable): OrionCortexRunResult.Unavailable {
            cycleObservations.isolatedCycle(cycle) { it.noAttempt(cycle) }
            return OrionCortexRunResult.Unavailable(reason)
        }
        preResourceReadiness().unavailable?.let { return@withContext unavailable(it) }
        val plan = byId[modelId]
        if (request.modelId != modelId || plan == null) return@withContext unavailable(OrionCortexUnavailable.PROFILE_MISMATCH)
        val preparationContext = currentCoroutineContext()
        preparationContext.ensureActive()
        val fingerprint = try {
            validateOrionInferenceRequest(request, contextTokens, threads)
            orionInferenceRequestFingerprint(request, contextTokens, threads)
        } catch (_: IllegalArgumentException) { return@withContext unavailable(OrionCortexUnavailable.MODEL_UNAVAILABLE) }
        val lifecycle = OrionInferenceLifecycle(request, clock)
        fun checkRequest() {
            preparationContext.ensureActive()
            val status = lifecycle.status()
            if (status.terminal != null) throw PreparationStopped(status)
        }
        try {
            requestHistory.existingResult(request.requestId, fingerprint)?.let {
                runtimeCapture?.retainedResult()
                cycleObservations.isolatedCycle(cycle) { observer -> observer.retained(cycle) }
                return@withContext OrionCortexRunResult.Completed(it)
            }
            checkRequest()
            if (discoverInventory() == null) return@withContext unavailable(OrionCortexUnavailable.PROCESS_INVENTORY_UNAVAILABLE)
            checkRequest()
            val beforeRecovery = database.models().find(modelId)
            // One registry row per request: no scan or hash work joins mandatory Core startup.
            recovery.withLock {
                checkRequest()
                // A later interrupted import may appear after the initial cursor
                // completed. Reconcile only that selected row, never reopen a scan.
                if (beforeRecovery?.status in setOf("IMPORTED", "VALIDATING")) importer.recoverSelected(modelId, ::checkRequest)
                if (!copiesClean) {
                    val copies = importer.cleanupInterruptedCopies(25, ::checkRequest)
                    copiesClean = !copies.needsContinuation && copies.blocked == 0
                }
                if (!recoveryComplete) {
                    val page = importer.recoverPage(recoveryAfter, 1, ::checkRequest)
                    recoveryAfter = page.nextAfterModelId
                    recoveryComplete = recoveryAfter == null
                }
                if (!unregisteredClean) {
                    val files = importer.cleanupUnregisteredFiles(unregisteredAfter, 1, ::checkRequest)
                    unregisteredAfter = files.nextAfterFileName
                    unregisteredClean = unregisteredAfter == null && files.blocked == 0
                }
            }
            checkRequest()
            // A pending selected row never gains authority in this same attempt merely through recovery.
            if (beforeRecovery?.status != "READY") return@withContext unavailable(OrionCortexUnavailable.MODEL_NOT_READY)
            val selected = database.models().find(modelId)
            if (!profileMatchesReadyModel(plan, selected, contextTokens, threads, request.maxTokens))
                return@withContext unavailable(OrionCortexUnavailable.PROFILE_MISMATCH)
            cycleObservations.isolatedCycle(cycle) { it.trustedModel(cycle, plan.model.modelId) }
            val descriptor = importer.openReadOnly(modelId, ::checkRequest)
                ?: return@withContext unavailable(OrionCortexUnavailable.MODEL_UNAVAILABLE)
            descriptor.use {
                checkRequest()
                if (closed) return@withContext unavailable(OrionCortexUnavailable.CLOSED)
                if (!coreReady()) return@withContext unavailable(OrionCortexUnavailable.CORE_NOT_READY)
                val ownedClient = synchronized(monitor) {
                    if (closed) null else client ?: OrionCortexClient(app, clock,
                        resources = { id, context, workerThreads, tokens -> synchronized(resourceMonitor) {
                            val cycleClient = client
                            val cycleCallback = cycleObservations.isolatedCycle {
                                cycleClient?.cycleCallbackScope(OrionCycleCallback.RESOURCE)?.takeIf { it.token.owner === cycleScope }
                            }
                            val snapshot = if (coreReady() && discoverInventory() != null) byId[id]?.let { trusted ->
                                observer?.observe(trusted, workerThreads, context, tokens)
                            } else null
                            observation = snapshot?.observation
                            val decision = checkNotNull(governor).evaluate()
                            if (cycleCallback != null) cycleObservations.isolatedCycle(cycleCallback.token) {
                                it.governor(cycleCallback, cycleClient?.cycleEndpoint(cycleCallback), snapshot, decision)
                            }
                            resourceFacts.recordGovernorFact(snapshot, decision)
                        } },
                        restart = {
                            val cycleClient = client
                            val cycleCallback = cycleObservations.isolatedCycle {
                                cycleClient?.cycleCallbackScope(OrionCycleCallback.RESTART)?.takeIf { it.token.owner === cycleScope }
                            }
                            val guard = checkNotNull(restart)
                            val snapshot = if (coreReady() && discoverInventory() != null)
                                observer?.observe(null, 1, 32, 1) else null
                            val decision = guard.evaluate(snapshot?.aiExitHistory)
                            if (cycleCallback != null) cycleObservations.isolatedCycle(cycleCallback.token) {
                                it.restart(cycleCallback, cycleClient?.cycleEndpoint(cycleCallback), snapshot, decision)
                            }
                            resourceFacts.recordRestartFact(snapshot, decision)
                        },
                        requestHistory = requestHistory, cycleObservations = cycleObservations).also { client = it }
                } ?: return@withContext unavailable(OrionCortexUnavailable.CLOSED)
                if (runtimeCapture != null && selected != null) runtimeCapture.selected(this@OrionCortexRuntimeOwner,
                    selected.sha256, selected.sizeBytes, request.requestId, request.deadline, timing?.maximumObservationAgeMillis)
                OrionCortexRunResult.Completed(ownedClient.runInference(checkNotNull(selected), it, request,
                    contextTokens, threads, cycle, runtimeCapture, onChunks))
            }
        } catch (stopped: PreparationStopped) {
            val invocation = cycleObservations.isolatedCycle(cycle) { if (cycle == null) null else OrionCortexCycleInvocation() }
            val status = requestHistory.runOnce(request.requestId, fingerprint) {
                invocation?.logicalOwnerEntered = true
                cycleObservations.isolatedCycle(cycle) { it.logicalOwner(cycle, request.requestId) }
                stopped.status
            }
            cycleObservations.isolatedCycle(cycle) { it.clientResult(cycle, invocation?.logicalOwnerEntered?.not()) }
            OrionCortexRunResult.Completed(status)
        } catch (cancelled: CancellationException) { throw cancelled }
          catch (_: network.orion.ai.api.OrionRetiredRequestException) { unavailable(OrionCortexUnavailable.REQUEST_RETIRED) }
          catch (interrupted: InterruptedException) { Thread.currentThread().interrupt(); throw interrupted }
          catch (_: Exception) { unavailable(OrionCortexUnavailable.MODEL_UNAVAILABLE) }
    }

    /** Explicit manual phase after run. No port creation, bind, clock or resource refresh. */
    fun readCycleObservation(token: OrionCortexCycleToken): OrionCortexCycleReceipt? {
        val scope = cycleScope ?: return null
        val read = cycleObservations.isolatedCycle(token) { it.prepareRead(scope, token) } ?: return null
        if (!read.mayQuery) return cycleObservations.isolatedCycle(token) { it.completeRead(read, null, false) }
        val selected = synchronized(monitor) { if (closed) null else client }
        val currentBefore = cycleObservations.isolatedCycle(token) {
            selected?.cycleEndpointCurrent(token, read.clientScope, read.endpoint)
        } == true
        val metrics = if (!currentBefore || read.logicalId == null) null else try {
            selected?.generationMetrics(read.logicalId)
        } catch (_: Throwable) { null }
        val currentAfter = synchronized(monitor) { !closed && client === selected } && cycleObservations.isolatedCycle(token) {
            selected?.cycleEndpointCurrent(token, read.clientScope, read.endpoint)
        } == true
        return cycleObservations.isolatedCycle(token) { it.completeRead(read, metrics, currentBefore && currentAfter) }
    }

    fun releaseCycleObservation(token: OrionCortexCycleToken): Boolean = cycleScope?.let { scope ->
        cycleObservations.isolatedCycle(token) { it.release(scope, token) }
    } == true

    private class PreparationStopped(val status: OrionInferenceStatus) : RuntimeException("Cortex preparation stopped.")

    @Suppress("DEPRECATION")
    private fun discoverInventory(): Set<String>? = try {
        val info = app.packageManager.getPackageInfo(app.packageName, PackageManager.GET_ACTIVITIES or
            PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS or
            PackageManager.MATCH_DISABLED_COMPONENTS)
        val components = sequenceOf(info.activities?.asSequence(), info.services?.asSequence(),
            info.receivers?.asSequence(), info.providers?.asSequence()).filterNotNull().flatten()
            .take(257).map { it.processName }.toList()
        supportedCortexInventory(app.packageName, info.applicationInfo?.processName, components)
    } catch (_: Exception) { null }

    override fun close() {
        val owned = synchronized(monitor) { closed = true; client.also { client = null } }
        owned?.close()
    }
}

internal fun validModelHash(value: String) = value.matches(Regex("[a-f0-9]{64}")) && value.any { it != '0' }

internal fun profileMatchesReadyModel(plan: OrionInferenceResourcePlan, model: ModelRegistryEntity?,
    contextTokens: Int, threads: Int, tokens: Int): Boolean {
    val contextLimit = model?.contextLimit ?: return false
    return model.status == "READY" && validModelHash(model.modelId) && model.modelId == model.sha256 &&
        model.modelId == plan.model.modelId && model.sizeBytes > 0 && plan.model.estimatedMemoryBytes >= model.sizeBytes &&
        contextTokens in 32..plan.maxContext && contextTokens <= contextLimit &&
        threads in 1..plan.maxThreads && tokens in 1..plan.maxTokens
}

/** Null component process inherits the trusted application default; unknown inventories deny. */
internal fun supportedCortexInventory(mainName: String, applicationProcess: String?, components: List<String?>): Set<String>? {
    if (mainName.isBlank() || ':' in mainName || applicationProcess != mainName) return null
    val bounded = components.take(257)
    if (bounded.size > 256) return null
    val names = bounded.map { name -> if (name == null) mainName else if (name.startsWith(':')) mainName + name else name }.toSet() + mainName
    return names.takeIf { it == setOf(mainName, "$mainName:ai") }
}
