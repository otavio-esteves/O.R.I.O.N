from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,time
W=Path('/tmp/orion-client-owner-capture-20261116')
E=Path('/tmp/orion-client-capture-android-20261116'); R=E/'red2'; R.mkdir(exist_ok=True)
A='/home/otavio/Android/Sdk/platform-tools/adb'; S='emulator-5596'; N='OrionCaptureHooks20261116'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(args,timeout=30): return subprocess.run(args,capture_output=True,text=True,timeout=timeout)
def adb(*args,timeout=30): return run([A,'-s',S,*args],timeout)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip()
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert source=='7de2331a8f154e1ca822604713be52d6040cd165'
files={}
for package,relative,label in [('network.orion','app/build/outputs/apk/debug','app'),('network.orion.test','app/build/outputs/apk/androidTest/debug','test')]:
 folder=W/relative; meta=json.loads((folder/'output-metadata.json').read_text())
 assert meta['applicationId']==package and len(meta['elements'])==1
 original=folder/meta['elements'][0]['outputFile']; copied=R/(label+'.apk'); shutil.copy2(original,copied)
 files[package]={'path':str(copied),'sha256':sha(copied),'sizeBytes':copied.stat().st_size}
(R/'build-binding.json').write_text(json.dumps({'sourceCommit':source,'sourceTree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=W,text=True).strip(),'environment':'DOCKER_BUILD','runtimeEnvironment':'ANDROID_EMULATOR','physicalEvidence':False,'purpose':'Expected RED2 disconnect regression; turn fix retained; lost/close intentionally unfixed','files':files},indent=2)+'\n')
devices=run([A,'devices']).stdout
assert S not in devices, 'Refuse to reuse any existing device on owned serial'
assert not any('orion-android-build' in line for line in run(['docker','ps','--format','{{.Names}}']).stdout.splitlines()), 'Do not boot during Gradle'
log=(E/'emulator-red2.log').open('wb')
process=subprocess.Popen(['/home/otavio/Android/Sdk/emulator/emulator','-avd',N,'-port','5596','-no-window','-no-audio','-no-snapshot','-gpu','swiftshader','-cores','4','-memory','3072','-no-boot-anim'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
log.close()
(E/'owned-emulator-red2.json').write_text(json.dumps({'pid':process.pid,'avd':N,'serial':S,'environment':'ANDROID_EMULATOR','physicalEvidence':False,'phase':'RED2'},indent=2)+'\n')
print('Owned emulator launched',process.pid,flush=True)
start=time.monotonic()
while time.monotonic()-start<180:
 if process.poll() is not None: raise RuntimeError('Owned emulator exited before boot')
 status=adb('shell','getprop','sys.boot_completed',timeout=10)
 if status.returncode==0 and status.stdout.strip()=='1': break
 time.sleep(2)
else: raise RuntimeError('Owned emulator boot unavailable')
assert adb('emu','avd','name').stdout.splitlines()[0]==N
info={}
for key in ['ro.build.version.sdk','ro.product.cpu.abi','ro.kernel.qemu','ro.hardware','ro.build.fingerprint']:
 response=adb('shell','getprop',key); assert response.returncode==0; info[key]=response.stdout.strip()
assert info['ro.build.version.sdk']=='35' and info['ro.product.cpu.abi']=='x86_64' and info['ro.kernel.qemu']=='1'
info['pageSizeBytes']=int(adb('shell','getconf','PAGESIZE').stdout.strip()); assert info['pageSizeBytes']==4096
(E/'actual-emulator-environment.json').write_text(json.dumps({'environment':'ANDROID_EMULATOR','physicalEvidence':False,'properties':info},indent=2)+'\n')
print('Boot complete; installing owned APK pair',flush=True)
for package,data in files.items():
 result=adb('install','-r','-t',data['path'],timeout=120)
 (R/(package+'-install.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0 and 'Success' in result.stdout
 paths=adb('shell','pm','path',package).stdout.strip().splitlines()
 assert len(paths)==1 and paths[0].startswith('package:/data/app/')
 remote=paths[0][len('package:'):]; assert re.fullmatch(r'[A-Za-z0-9_/~+=.\-]+',remote)
 target=R/(package+'-installed.apk'); pulled=adb('pull',remote,str(target),timeout=120)
 assert pulled.returncode==0 and sha(target)==data['sha256']
 data['installedApkSha256']=sha(target)
(R/'installed-binding.json').write_text(json.dumps(files,indent=2)+'\n')
selector='network.orion.app.ai.OrionCortexRuntimeCaptureClientTest'
result=adb('shell','am','instrument','-w','-r','-e','class',selector,'network.orion.test/androidx.test.runner.AndroidJUnitRunner',timeout=120)
output=result.stdout+result.stderr; (R/'regression-instrumentation.log').write_text(output)
expected='A lost connection must invalidate its cached capture before original publication can block'
reproduced=expected in output and 'INSTRUMENTATION_STATUS_CODE: -2' in output and 'Tests run: 11,  Failures: 1' in output
(R/'result.json').write_text(json.dumps({'environment':'ANDROID_EMULATOR','physicalEvidence':False,'sourceCommit':source,'selector':selector,'adbExitCode':result.returncode,'expectedFailureReproduced':reproduced,'inferenceProfileQualified':False,'gateClosed':False},indent=2)+'\n')
print('RED2 expected failure reproduced:',reproduced,flush=True)
if not reproduced: raise RuntimeError('Expected regression failure not established; inspect raw output')
