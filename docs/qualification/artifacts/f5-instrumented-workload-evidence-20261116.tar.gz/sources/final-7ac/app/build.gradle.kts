plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

val nativeGateText = providers.fileContents(rootProject.layout.projectDirectory.file(
    "docs/compatibility/native-compatibility-gate.json")).asText.get()
val nativeStatusMatches = Regex("\"status\"\\s*:\\s*\"(PENDING|PASS|FAIL|NOT_APPLICABLE_NO_NATIVE_ARTIFACTS)\"")
    .findAll(nativeGateText).toList()
check(nativeStatusMatches.size == 1) { "Native qualification metadata must have one recognized status." }
val nativeQualificationStatus = nativeStatusMatches.single().groupValues[1]
val qualificationFlag = providers.gradleProperty("orionQualificationRelease").orElse("false").get()
check(qualificationFlag in setOf("true", "false")) { "orionQualificationRelease must be true or false." }
val qualificationEnabled = qualificationFlag == "true"
val physicalBaselineFlag = providers.gradleProperty("orionPhysicalBaseline").orElse("false").get()
check(physicalBaselineFlag in setOf("true", "false")) { "orionPhysicalBaseline must be true or false." }
val physicalBaselineEnabled = physicalBaselineFlag == "true"
check(!physicalBaselineEnabled || qualificationEnabled) { "Physical baseline requires the separate qualification identity." }
val cortexReadinessFlag = providers.gradleProperty("orionCortexReadinessProbe").orElse("false").get()
check(cortexReadinessFlag in setOf("true", "false")) { "orionCortexReadinessProbe must be true or false." }
val cortexReadinessEnabled = cortexReadinessFlag == "true"
check(!cortexReadinessEnabled || qualificationEnabled) { "Cortex readiness probe requires the separate qualification identity." }
val exitEvidenceCaptureFlag = providers.gradleProperty("orionExitEvidenceCapture").orElse("false").get()
check(exitEvidenceCaptureFlag in setOf("true", "false")) { "orionExitEvidenceCapture must be true or false." }
val exitEvidenceCaptureEnabled = exitEvidenceCaptureFlag == "true"
check(!exitEvidenceCaptureEnabled || qualificationEnabled) { "Exit evidence capture requires the separate qualification identity." }
val cortexSingleAttemptFlag = providers.gradleProperty("orionCortexSingleAttempt").orElse("false").get()
check(cortexSingleAttemptFlag in setOf("true", "false")) { "orionCortexSingleAttempt must be true or false." }
val cortexSingleAttemptEnabled = cortexSingleAttemptFlag == "true"
check(!cortexSingleAttemptEnabled || qualificationEnabled) { "Single attempt requires the separate qualification identity." }
val cortexRuntimeCaptureFlag = providers.gradleProperty("orionCortexRuntimeCapture").orElse("false").get()
check(cortexRuntimeCaptureFlag in setOf("true", "false")) { "orionCortexRuntimeCapture must be true or false." }
val cortexRuntimeCaptureEnabled = cortexRuntimeCaptureFlag == "true"
check(!cortexRuntimeCaptureEnabled || qualificationEnabled) { "Runtime capture requires the separate qualification identity." }
val cortexInstrumentedWorkloadFlag = providers.gradleProperty("orionCortexInstrumentedWorkload").orElse("false").get()
check(cortexInstrumentedWorkloadFlag in setOf("true", "false")) { "orionCortexInstrumentedWorkload must be true or false." }
val cortexInstrumentedWorkloadEnabled = cortexInstrumentedWorkloadFlag == "true"
check(!cortexInstrumentedWorkloadEnabled || qualificationEnabled) { "Instrumented workload requires the separate qualification identity." }
check(listOf(physicalBaselineEnabled, cortexReadinessEnabled, exitEvidenceCaptureEnabled, cortexSingleAttemptEnabled,
    cortexRuntimeCaptureEnabled, cortexInstrumentedWorkloadEnabled).count { it } <= 1) {
    "Qualification measurement modes are mutually exclusive."
}

android {
    namespace = "network.orion.app"
    ndkVersion = libs.versions.ndk.get()
    compileSdk = libs.versions.compile.sdk.get().toInt()

    defaultConfig {
        applicationId = "network.orion"
        minSdk = libs.versions.min.sdk.get().toInt()
        targetSdk = libs.versions.target.sdk.get().toInt()
        testInstrumentationRunner = when {
            cortexInstrumentedWorkloadEnabled -> "network.orion.app.compatibility.OrionCortexInstrumentedWorkloadInstrumentation"
            cortexRuntimeCaptureEnabled -> "network.orion.app.compatibility.OrionCortexRuntimeCaptureInstrumentation"
            cortexSingleAttemptEnabled -> "network.orion.app.compatibility.OrionCortexSingleAttemptInstrumentation"
            exitEvidenceCaptureEnabled -> "network.orion.app.compatibility.OrionExitEvidenceCaptureInstrumentation"
            cortexReadinessEnabled -> "network.orion.app.compatibility.OrionCortexReadinessInstrumentation"
            physicalBaselineEnabled -> "network.orion.app.compatibility.OrionPhysicalBaselineInstrumentation"
            qualificationEnabled -> "network.orion.app.compatibility.OrionQualificationInstrumentation"
            else -> "androidx.test.runner.AndroidJUnitRunner"
        }
        versionCode = 6
        versionName = "0.5.0-development"
        resValue("string", "orion_native_qualification_status", nativeQualificationStatus)
        // A normal APK never gains this observer, even with qualification properties supplied.
        buildConfigField("boolean", "ORION_CORTEX_SINGLE_ATTEMPT", "false")
        buildConfigField("boolean", "ORION_CORTEX_RUNTIME_CAPTURE", "false")
        buildConfigField("boolean", "ORION_CORTEX_INSTRUMENTED_WORKLOAD", "false")
    }

    buildTypes {
        debug { ndk { abiFilters += setOf("arm64-v8a", "x86_64") } }
        release { ndk { abiFilters += "arm64-v8a" } }
        create("qualificationRelease") {
            initWith(getByName("release"))
            applicationIdSuffix = ".qualification"
            matchingFallbacks += listOf("release")
            isDebuggable = false
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("debug")
            ndk.abiFilters.clear()
            ndk.abiFilters += setOf("arm64-v8a", "x86_64")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            buildConfigField("boolean", "ORION_CORTEX_SINGLE_ATTEMPT", cortexSingleAttemptEnabled.toString())
            buildConfigField("boolean", "ORION_CORTEX_RUNTIME_CAPTURE", cortexRuntimeCaptureEnabled.toString())
            buildConfigField("boolean", "ORION_CORTEX_INSTRUMENTED_WORKLOAD", cortexInstrumentedWorkloadEnabled.toString())
        }
    }

    buildFeatures {
        compose = true
        resValues = true
        buildConfig = true
    }

    sourceSets.getByName("androidTest").assets.directories.add("$rootDir/data/database/schemas")
    if (qualificationEnabled) {
        testBuildType = "qualificationRelease"
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").kotlin.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/qualificationAndroidTest/java")
    }
    if (physicalBaselineEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/physicalBaselineTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/physicalBaselineTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/physicalBaselineAndroidTest/java")
    }
    if (cortexReadinessEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/cortexReadinessTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/cortexReadinessTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/cortexReadinessAndroidTest/java")
    }
    if (exitEvidenceCaptureEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/exitEvidenceCaptureTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/exitEvidenceCaptureTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/exitEvidenceCaptureAndroidTest/java")
    }
    if (cortexRuntimeCaptureEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/cortexRuntimeCaptureTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/cortexRuntimeCaptureTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").kotlin.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/cortexRuntimeCaptureAndroidTest/java")
    }
    if (cortexInstrumentedWorkloadEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/cortexInstrumentedWorkloadTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/cortexInstrumentedWorkloadTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").kotlin.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/cortexInstrumentedWorkloadAndroidTest/java")
    }
    if (cortexSingleAttemptEnabled) {
        sourceSets.getByName("qualificationRelease").kotlin.directories.add("src/cortexSingleAttemptTarget/kotlin")
        buildTypes.getByName("qualificationRelease").proguardFiles("src/cortexSingleAttemptTarget/proguard-rules.pro")
        sourceSets.getByName("androidTest").java.directories.clear()
        sourceSets.getByName("androidTest").kotlin.directories.clear()
        sourceSets.getByName("androidTest").java.directories.add("src/cortexSingleAttemptAndroidTest/java")
    }
}

androidComponents.beforeVariants(androidComponents.selector().withBuildType("qualificationRelease")) {
    it.enable = qualificationEnabled
}

if (qualificationEnabled) {
    val qualificationApk = layout.buildDirectory.file("outputs/apk/qualificationRelease/app-qualificationRelease.apk").get().asFile
    val mapping = layout.buildDirectory.file("outputs/mapping/qualificationRelease/mapping.txt").get().asFile
    tasks.register<Exec>("verifyQualificationNativePackage") {
        group = "verification"
        description = "Checks explicit minified qualification APK, never the production release ABI policy."
        dependsOn("assembleQualificationRelease")
        inputs.files(qualificationApk, mapping, rootProject.file("scripts/benchmark/check-native-packages.sh"))
        environment("ORION_NDK_VERSION", libs.versions.ndk.get())
        doFirst { check(mapping.isFile && mapping.useLines { lines -> lines.any { it == "# compiler: R8" } }) { "R8 qualification mapping is missing." } }
        commandLine("sh", rootProject.file("scripts/benchmark/check-native-packages.sh"), "--qualification", qualificationApk)
    }
}

dependencies {
    implementation(project(":ai:api"))
    implementation(project(":ai:service"))
    // AGP aligns tests with their target APK. Room's schema serializers require the newer default methods.
    debugImplementation(libs.serialization.test.runtime)
    debugImplementation(project(":core:ipc"))
    testImplementation(libs.junit4)
    implementation(project(":core:common"))
    implementation(project(":scheduler"))
    implementation(libs.work.runtime)
    implementation(project(":core:health"))
    implementation(project(":core:time"))
    implementation(project(":core:observability"))
    implementation(project(":core:recovery"))
    implementation(project(":core:ingress"))
    implementation(project(":core:actions"))
    implementation(project(":core:commands"))
    implementation(project(":core:queries"))
    implementation(project(":core:orchestrator"))
    implementation(project(":core:policy"))
    implementation(project(":core:skills:metadata"))
    implementation(project(":core:model"))
    implementation(project(":core:resources"))
    implementation(project(":core:security"))
    implementation(project(":core:exitinfo"))
    implementation(project(":data:database"))
    implementation(project(":data:datastore"))
    implementation(project(":data:repository"))
    implementation(project(":data:actions"))
    implementation(project(":data:tasks"))
    implementation(project(":data:timers"))
    implementation(project(":skills:tasks"))
    implementation(project(":skills:device"))
    implementation(project(":data:events"))
    implementation(project(":feature:device"))
    implementation(project(":feature:activity"))
    implementation(project(":skills:reminders"))
    implementation(project(":data:reminders"))
    implementation(project(":feature:reminders"))
    implementation(project(":skills:timers"))
    implementation(project(":skills:memory"))
    implementation(project(":data:memory"))
    implementation(project(":feature:memories"))
    implementation(project(":feature:home"))
    implementation(project(":feature:tasks"))
    implementation(project(":feature:timers"))
    implementation(project(":skills:notifications"))
    implementation(project(":feature:notifications"))
    implementation(project(":feature:diagnostics"))
    implementation(project(":feature:settings"))
    implementation(libs.activity.compose)
    implementation(libs.compose.material3)
    implementation(libs.coroutines.android)
    if (!qualificationEnabled) {
        androidTestImplementation(platform(libs.compose.bom))
        androidTestImplementation(libs.compose.ui.test.junit4)
        androidTestImplementation(libs.androidx.test.runner)
        androidTestImplementation(libs.androidx.test.core)
        androidTestImplementation(libs.androidx.test.junit)
        // Compose's transitive Espresso 3.5 reflection targets an InputManager method removed in API 37.
        androidTestImplementation(libs.androidx.test.espresso.core)
        androidTestImplementation(libs.room.testing)
        androidTestImplementation(project(":data:actions"))
        androidTestImplementation(project(":data:repository"))
        androidTestImplementation(project(":data:events"))
        androidTestImplementation(project(":data:tasks"))
        androidTestImplementation(project(":core:queries"))
        androidTestImplementation(project(":data:reminders"))
        androidTestImplementation(project(":data:memory"))
    }
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.runtime)
}
