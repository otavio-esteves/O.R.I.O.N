from pathlib import Path
import hashlib,json,re,shutil,socket,subprocess,time
W=Path('/HOST_HOME_REDACTED/.cache/orion-codex-worktrees/orion-f5-instrumented-workload-20261116')
B=Path('/HOST_HOME_REDACTED/.cache/orion-codex-evidence/f5-workload-artifacts-20261116-compiler-fix')
E=Path('/HOST_HOME_REDACTED/.cache/orion-codex-evidence/f5-workload-r8-no-restart-20261116')
A='/HOST_HOME_REDACTED/Android/Sdk/platform-tools/adb'
S='EMULATOR_SERIAL_REDACTED';N='OrionF5Software20261116'
def run(args,timeout=30): return subprocess.run(args,capture_output=True,text=True,timeout=timeout)
def adb(*args,timeout=30): return run([A,'-s',S,*args],timeout)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(name,data): (E/name).write_text(json.dumps(data,indent=2)+'\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
binding=json.loads((B/'source-binding.json').read_text());artifacts=json.loads((B/'artifacts.json').read_text())['artifacts']
commit=binding['sourceCommit']
def frozen():
    assert git('rev-parse','HEAD')==commit and not git('status','--porcelain')
    assert all(sha(W/name)==value for name,value in binding['files'].items())
frozen()
assert S not in run([A,'devices']).stdout
assert not any('orion-android-build' in value for value in run(['docker','ps','--format','{{.Names}}']).stdout.splitlines())
for port in (5596,5597):
    with socket.socket() as sock: sock.bind(('127.0.0.1',port))
E.mkdir(exist_ok=False,parents=True)
write('source-binding.json',binding)
classes=['OrionCortexClientTest','OrionCortexOwnerDefaultTest','OrionCortexQueuedDeadlineTest','OrionCortexCycleClientTest','OrionCortexRuntimeCaptureClientTest','OrionCortexGenerationMetricsClientTest','OrionRuntimeMemorySamplerAndroidTest','OrionRuntimeCapsuleParcelGuardTest','OrionCortexRuntimeCaptureProgramAndroidTest','FoundationRuntimeTest','OrionInstrumentedWorkloadAndroidTest']
selected={}
for name in classes:
    files=list((W/'app/src/androidTest/kotlin/network/orion/app').rglob(name+'.kt'));assert len(files)==1
    namespace='network.orion.app.'+('' if name=='FoundationRuntimeTest' else 'ai.')
    selected[namespace+name]=files[0].read_text().count('@Test')
expected=sum(selected.values());assert expected==115
write('test-selection.json',{'classes':selected,'expected':expected,'syntheticClockAndEndpointFixtures':True,'physicalEvidence':False})
log=(E/'emulator.log').open('wb')
process=subprocess.Popen(['/HOST_HOME_REDACTED/Android/Sdk/emulator/emulator','-avd',N,'-port','5596','-no-window','-no-audio','-no-snapshot','-gpu','swiftshader','-cores','4','-memory','3072','-no-boot-anim'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
log.close();write('owned-emulator.json',{'pid':process.pid,'avd':N,'serial':S,'physicalEvidence':False,'environment':'ANDROID_EMULATOR'})
print('Owned emulator launched',process.pid,flush=True)
def install(label):
    data=artifacts[label];assert sha(data['path'])==data['sha256']
    response=adb('install','-r','-t',data['path'],timeout=120)
    (E/(label+'-install.log')).write_text(response.stdout+response.stderr)
    assert response.returncode==0 and 'Success' in response.stdout
    response=adb('shell','pm','path',data['package']);paths=response.stdout.strip().splitlines()
    assert response.returncode==0 and len(paths)==1 and paths[0].startswith('package:/data/app/')
    remote=paths[0][len('package:'):];assert re.fullmatch(r'[A-Za-z0-9_/~+=.\-]+',remote)
    target=E/(label+'-installed.apk');response=adb('pull',remote,str(target),timeout=120)
    assert response.returncode==0 and sha(target)==data['sha256']
    return dict(data,installedApkSha256=sha(target),installedPath=remote)
try:
    started=time.monotonic()
    while time.monotonic()-started<240:
        assert process.poll() is None,'Owned emulator exited before boot'
        response=adb('shell','getprop','sys.boot_completed',timeout=10)
        if response.returncode==0 and response.stdout.strip()=='1': break
        time.sleep(2)
    else: raise RuntimeError('Owned emulator boot unavailable')
    assert adb('emu','avd','name').stdout.splitlines()[0]==N
    info={}
    for prop in ('ro.build.version.sdk','ro.product.cpu.abi','ro.kernel.qemu','ro.hardware','ro.build.fingerprint'):
        response=adb('shell','getprop',prop);assert response.returncode==0;info[prop]=response.stdout.strip()
    info['pageSizeBytes']=int(adb('shell','getconf','PAGESIZE').stdout.strip())
    assert info['ro.build.version.sdk']=='35' and info['ro.product.cpu.abi']=='x86_64' and info['ro.kernel.qemu']=='1' and info['pageSizeBytes']==4096
    write('actual-environment.json',{'environment':'ANDROID_EMULATOR','physicalEvidence':False,'properties':info})
    installed={name:install(name) for name in ('captureApp','captureTest')};write('capture-installed-binding.json',installed)
    import sys,uuid
    sys.path.insert(0,str(W/'scripts/android'))
    import f5_instrumented_workload_adapters as QA
    import f5_instrumented_workload_protocol as QP
    launch=adb('shell','am','start','-W','-n','network.orion.qualification/network.orion.app.MainActivity',timeout=60)
    (E/'qualification-launch.log').write_text(launch.stdout+launch.stderr)
    assert launch.returncode==0 and 'Status: ok' in launch.stdout
    def instance():
        response=adb('shell','pidof','network.orion.qualification')
        text=response.stdout.strip();assert response.returncode==0 and re.fullmatch(r'[1-9][0-9]*',text)
        stat=adb('shell','cat','/proc/'+text+'/stat');assert stat.returncode==0
        fields=stat.stdout[stat.stdout.rfind(')')+2:].split();ticks=int(fields[19]);assert ticks>0
        count=adb('shell','settings','get','global','boot_count');assert count.returncode==0
        return dict(mainPid=int(text),kernelStartTicks=ticks,bootCount=int(count.stdout.strip()))
    before=instance();frames=[];run_id=str(uuid.uuid4());fixture_id=str(uuid.uuid4())
    for number in (1,2):
        command=[A,'-s',S,*QA.instrumentation_command('OPEN',run_id,fixture_id)]
        # One explicit framework command per checkpoint; stdout stays in RAM, nonce persists only as SHA.
        response=run(command,timeout=60)
        assert response.returncode==0,'No automatic rerun of a failed framework invocation'
        value,source_unused,status_unused=QA.receipt(response.stdout,'OPEN',run_id,fixture_id)
        assert source_unused is None and status_unused is None
        assert value['outcome']=='REFUSED' and value['refusal'] in {'NO_QUALIFIED_PROFILE','ALREADY_CONSUMED'}
        assert value['ownerCallInvoked'] is False and value['stamp']['mainPid']==before['mainPid']
        assert value['stamp']['bootCount']==before['bootCount']
        assert all(value[key] is False for key in QP.FALSE_FLAGS)
        current=instance();assert current==before,'MAIN instance changed at instrumentation finish'
        minimized=QP.journal_checkpoint(value);frames.append(minimized)
        write('qualified-open-'+str(number)+'.json',{'checkpoint':minimized,'rawTranscriptSha256':hashlib.sha256(response.stdout.encode()).hexdigest(),'rawTranscriptBytes':len(response.stdout.encode()),'rawTranscriptRetained':False,'mainInstanceAfterFinish':current,'physicalEvidence':False})
    assert frames[0]['sessionIdSha256']==frames[1]['sessionIdSha256'],'MAIN graph correlation nonce changed'
    for data in installed.values():
        response=adb('shell','sha256sum',data['installedPath']);assert response.returncode==0
        assert response.stdout.split()[0]==data['sha256']
    frozen()
    write('result.json',{'sourceCommit':commit,'environment':'ANDROID_EMULATOR','physicalEvidence':False,'mechanicalCases':0,'mechanicalCasesExecutedHere':False,'priorMechanicalCasesPassed':115,'priorMechanicalEvidence':'f5-workload-android-20261116/normal-result.json','actualMinifiedQualificationContextObserved':True,'actualNoRestartOpenCalls':2,'sameMainPidAndKernelStartTicksAfterEachFinish':True,'sameMainGraphNonceSha256':frames[0]['sessionIdSha256'],'actualCoreOwnerInvoked':False,'realOutcome':'REFUSED/NO_QUALIFIED_PROFILE','modelLoaded':False,'profileQualified':False,'fullF5GateClosed':False,'fullSoakGateClosed':False,'f6Authorized':False})
    print('CAUSAL NO-RESTART R8 OPEN PAIR COMPLETE; mechanical115 in separate prior run',flush=True)

finally:
    response=adb('emu','avd','name');cmdline=Path(f'/proc/{process.pid}/cmdline')
    owned=process.poll() is None and cmdline.exists() and N.encode() in cmdline.read_bytes() and response.returncode==0 and response.stdout.splitlines()[0]==N
    write('cleanup-ownership-check.json',{'pid':process.pid,'avd':N,'serial':S,'owned':owned,'identity':response.stdout})
    if owned:
        response=adb('emu','kill');(E/'emulator-stop.log').write_text(response.stdout+response.stderr)
        try: process.wait(timeout=30)
        except subprocess.TimeoutExpired: pass
        write('cleanup-result.json',{'ownedEmulatorExitCode':process.poll()})
