import hashlib,os,sys,tempfile,unittest,uuid
from pathlib import Path
from unittest import mock
sys.path.insert(0,'/workspace/scripts/android')
import f5_instrumented_workload_journal as J
import f5_instrumented_workload_adapters as A
import test_f5_instrumented_workload_harness as fixtures

class ReviewRegression(unittest.TestCase):
    def test_publisher_receipt_matches_the_inode_actually_published(self):
        with tempfile.TemporaryDirectory() as path:
            fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
            try:
                journal=J.InvocationJournal.__new__(J.InvocationJournal)
                journal.fd=fd;journal._check_chain=lambda:None;journal.inspection_required=False
                intended=b'{"durableIntent":"owned-only"}'
                actual_replace=J.os.replace
                def substituted(src,dst,**kwargs):
                    os.unlink(src,dir_fd=fd)
                    foreign=os.open(src,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o400,dir_fd=fd)
                    try:os.write(foreign,b'{"foreign":"substituted"}')
                    finally:os.close(foreign)
                    return actual_replace(src,dst,**kwargs)
                with mock.patch.object(J.os,'replace',side_effect=substituted):
                    try:receipt=journal._publish('state.json',intended)
                    except (J.P.Invalid,J.base.CommitUncertain,J.base.StoreError,OSError):return
                self.assertEqual(hashlib.sha256((Path(path)/'state.json').read_bytes()).hexdigest(),receipt)
            finally:os.close(fd)

    def test_transport_cleanup_keeps_original_interruption_and_attempts_all_cleanup(self):
        original=GeneratorExit('synthetic original')
        selector=mock.Mock();selector.select.side_effect=original;selector.close.side_effect=OSError('synthetic cleanup')
        child=mock.Mock();child.stdout.fileno.return_value=83;child.poll.return_value=None
        adapter=A.FixedAdb('owned-adb','EXPLICIT_PHYSICAL_SERIAL',1000)
        clock=fixtures.Time().factory()
        command=A.instrumentation_command('OPEN',str(uuid.UUID(int=1)),str(uuid.UUID(int=2)))
        with mock.patch.object(A.HostClock,'linux',return_value=clock),mock.patch.object(A.subprocess,'Popen',return_value=child),mock.patch.object(A.selectors,'DefaultSelector',return_value=selector),mock.patch.object(A.os,'set_blocking'):
            with self.assertRaises(GeneratorExit) as caught:adapter(*command)
        self.assertIs(original,caught.exception)
        selector.close.assert_called_once();child.kill.assert_called_once();child.wait.assert_called_once_with(timeout=1);child.stdout.close.assert_called_once()
        self.assertTrue(adapter.uncertain)

    def test_cleanup_propagates_original_interrupt_after_unknown_record_attempt(self):
        fixture=fixtures.WorkloadTest(methodName='runTest');fixture.setUp()
        try:
            fixture.start();fixture.finish_work()
            original=GeneratorExit('synthetic cleanup interruption')
            actual=fixture.producer.call
            def interrupted(operation,attempt_id=None):
                if operation=='CLEANUP':raise original
                return actual(operation,attempt_id)
            fixture.producer.call=interrupted
            with self.assertRaises(GeneratorExit) as caught:fixture.executor.cleanup()
            self.assertIs(original,caught.exception)
            self.assertEqual('UNKNOWN',fixture.executor.report()['status'])
        finally:fixture.doCleanups()

if __name__=='__main__':unittest.main()
