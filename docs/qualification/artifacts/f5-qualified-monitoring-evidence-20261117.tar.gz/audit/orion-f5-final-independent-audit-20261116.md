# O.R.I.O.N. — independent F5 software audit and issue #165 recheck

Date: 2026-11-16. Auditor: independent read-only agent `/root/final_f5_audit`.

## Result

The initial audit identified one P2 software finding and no P1. The independent issue #165 recheck found that P2 resolved in the four frozen files listed below. No additional demonstrable P1/P2 was identified in the reviewed code paths or correction diff. This is a scoped source-review conclusion, not an exhaustive proof of correctness, a current CI result, a physical qualification or F5 formal closure.

## Source and exact scope

The initial integrated Core/APP/HOST review used clean source commit `5cb524638169252549fd7ea46e15b750ff31e1f9` in `<LOCAL_PATH>`. The later documentary map used `3208ace77fbbf3b58b0b91bc89e6df8a9091c6e6` in that worktree. A read-only Git comparison confirmed that the difference between these commits contains only eight qualification documentation/evidence paths; no runtime or HOST source changed in that comparison.

The audit read AGENTS.md, the relevant Architecture V3.2 / Master Plan V1.2 F5 and soak contracts, and accepted ADR-0001/0002/0003. Selected critical source paths reviewed included:

- MAIN bootstrap/Foundation/Core readiness and Startup Barrier ownership; Room and maintenance/retention boundaries; deterministic outbox/ingress/recovery crossings.
- Cortex Owner/Client/Service and native/IPC interfaces, resource and restart admission, inventory/headroom, model opening/import recovery, deadlines/boot identity, request history/terminality, unload and explicit rebind.
- Runtime capture/encoder/assembly and bounded memory observation; instrumented workload #160 and manual Core procedure #163, original-process-death settlement, UNKNOWN/replay/cleanup fences, durable HOST intents and ACK concurrency.
- Paired exit reader/correlation, millisecond quantization and causal windows, original resource-policy sidecars, payload minimization and false qualification/authority flags.
- Concrete passive resource/exit and maintenance-history collectors and their relationship to the qualification APK and existing MAIN maintenance producer.

This was a targeted end-to-end audit of those F5 boundaries, not a claim that every repository file or every branch of each implementation was independently executed.

## Initial P2 and resolution

Finding: the concrete passive resource/exit and maintenance-history collectors fixed their package to `network.orion`, whereas APP #160/#163 requires non-debuggable `network.orion.qualification`. With only qualification installed, package/hash/UID lookup refused before collection. With both installed, the collectors queried another package/UID/database. Instrumented workload resource observations alone did not replace Event/Ingress/retention/database-growth history.

Initial locations: `scripts/android/record-soak-observation.py:20,126-127,154,160-161`; `scripts/android/record-maintenance-history.py:105-107`; qualification identity in `app/src/cortexInstrumentedWorkloadTarget/kotlin/network/orion/app/ai/OrionCortexInstrumentedWorkloadBridge.kt:21` and `app/build.gradle.kts`.

An in-memory HOST-only fake-ADB demonstration reproduced refusal of a valid qualification-only installation. Both helpers queried `network.orion`. This demonstration executed no real ADB command and wrote no repository file; it is synthetic functional evidence, not canonical Docker or Android runtime evidence.

The issue #165 correction was reviewed at `<LOCAL_PATH>`, against `/tmp/orion-165-full-freeze-20261116.json`:

- `scripts/android/record-maintenance-history.py` — SHA-256 `3469d1cb48d36b387f8ac3da6e9506a48026ce9469a409f754fc248966ca3b23`.
- `scripts/android/record-soak-observation.py` — SHA-256 `84006c7b24ce32f283e38be37a25a260be89f04603f620337645c08469156f0d`.
- `scripts/android/test_maintenance_history_harness.py` — SHA-256 `a2ce90141d13deee149fc9aa687d0da87368e21f2f2cbfa72f44db4783f69378`.
- `scripts/android/test_soak_observation_harness.py` — SHA-256 `0ff99669c55494a71bac98d93cfc19a30abb30e8214fe74eedf0f5784dd18468`.

All four current file hashes matched the frozen manifest during recheck and again before this report was written. The recheck read the entire correction diff, the focused harnesses and F4 caller/consumer crossings.

The correction closes the finding: exact package allowlist before I/O; selected-package APK/UID/PID/memory/exit namespace; exact UID filtering and before/after UID fences for maintenance polls; no fallback to the principal package; identity loss retains gaps/discards mixed target metrics. Existing callers retain the main-package default and additive report fields do not change the F4 consumer's selected fields. Non-debuggable private storage stays unavailable/INCOMPLETE; the existing MAIN technical log supplies its actual twenty maintenance metrics without adding an APP authority, storage surface or profile default.

## Checks and evidence actually used

The auditor executed read-only Git inspection (`status --short`, `log`, `rev-parse`, `diff --stat`, `diff --name-only`, source diffs and `diff --check`), text/file inspection, SHA-256 comparison of the four frozen correction files and the synthetic in-memory helper demonstration described above. `git diff --check` completed without output. Repository changes visible at the correction worktree were the authorized author's four files; the auditor made none.

The auditor inspected `/tmp/orion-165-full-host-20261116.log`, which reports `Ran 629 tests in 46.260s` and `OK`. This is another actor's recorded canonical Docker HOST execution, not a test run performed by this auditor. Its cases are not added to any global or unique test total. The reported focused results were not independently rerun here.

No Gradle, build, lint, Docker test suite, Android instrumentation, ADB, emulator, physical-device or current CI run was executed by this auditor. No current required-CI PASS or merge status is asserted.

## Limits and remaining gate boundaries

No physical device was available. This report proves no real model performance, resource calibration, native/API hardware matrix, actual MemoryLimiter incident, platform override restoration, continuous monitoring coverage, autonomy, uninterrupted 24-hour operation or post-Cortex soak. Existing gaps, unavailable values and UNKNOWN outcomes remain explicit. Empty trusted production configuration remains absent; this audit grants no defaults, profile, policy authority or production inference permission.

F4 physical/stability prerequisites, formal F5/CORTEX_RUNTIME_READY and F6 remain outside this approval. Global checklist/runtime-gate documentation needs its planned source/status reconciliation while preserving historical source identities, failed attempts and scoped test counts. That reconciliation was mapped separately and is not misreported as a new code defect.

Disposition: one original P2 resolved in frozen issue #165 sources; zero new demonstrable P1/P2 in this audit/recheck scope. Awaiting the parent's integrated-document review request.

## Supplement — finalized issue #165 local commit

After the initial recheck/report, the implementation author finalized local commit `4c987d761c875a4259c113098724f4d569f8d21d` on `fix/f5-qualified-monitoring-20261116`, based on `5cb524638169252549fd7ea46e15b750ff31e1f9`. Read-only Git inspection observed a clean worktree at that commit. The auditor compared all six paths in `/tmp/orion-165-final-files-20261116.json`: all matched. The four source/test hashes are unchanged from the original reviewed freeze; the two added paths are the qualification monitoring work package and its F4 procedure link. Their scope/limitations were read and introduce no additional P1/P2 finding. A minor method-name documentation typo (`runMaintenance` versus actual `performMaintenance`) was communicated separately; it is not a software blocker. This local commit inspection asserts neither merge nor current CI approval. The parent retains ownership of final integrated-document reconciliation and any later runtime validation.

## Supplement — test-only MAIN ownership fixture correction

The auditor read local commit `3d34e3505e0bf12e26b15020e452c6981ebb5fb9`. Relative to `3208ace77fbbf3b58b0b91bc89e6df8a9091c6e6`, its two paths are `app/src/androidTest/kotlin/network/orion/app/ai/OrionCortexOwnerDefaultTest.kt` and `docs/qualification/F5-ExitPolicySource-WorkPackage.md`. A read-only Git diff of APP main/core/AI/data/scheduler/HOST source is empty: functional source remains equivalent to 3208 for these paths.

One test method was replaced, rather than removed. It now constructs three Owners with the actual normal MAIN Context, distinguishes absent diagnostic configuration/passive buffer from supplied fixture inputs and requires the qualification exit source to stay absent in all normal-artifact cases. A substituted qualification package name is retained as an explicit negative constructor control: the existing unchanged MAIN ownership guard must throw IllegalArgumentException. Functional Clock and native bind counts must remain zero. The correction is consistent with the existing boundary; no additional P1/P2 was identified by this source recheck.

Root reported that the first normal Android selection on source3208 had 117 passing controls and one failing new fixture out of 118, because the substituted package was correctly rejected by the guard. This original failure must remain a failed execution record. The auditor did not execute or claim a successful rerun on 3d34. A real positive configured qualification exit-source factory is not exercised by this normal test or by a fake Context and remains explicitly unexecuted here.

## Supplement — recorded #165 read-only emulator mechanics

The auditor subsequently inspected root-produced minimized evidence under `<LOCAL_PATH>`: result/source-binding/coexisting-installed-identities, resource and maintenance reports, and cleanup result. It binds collector commit4c987 and APP source3208 in ANDROID_EMULATOR. The recorded result reports selected-target binding, two coexisting package identities with distinct UIDs and actual qualification MAIN memory. The resource report honestly remains INCOMPLETE with inaccessible private storage; its package/installed APK/UID endpoints match. The maintenance report contains three baseline events and zero first-seen subsequent events. These are existing baseline observations, not observed post-baseline queue/growth progress, pruning success, continuous monitoring or autonomy. Owned-emulator cleanup reports exit0.

These records were produced/executed by root, not by this auditor. This supplement records evidence inspection only and grants no physical, profile, MemoryLimiter, real24h, F4/F5/F6, positive configured-factory or current-CI approval. The independent finding disposition remains one original P2 resolved, zero additional demonstrable P1/P2 in the reviewed scope.
